import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductStockComponent } from './product-stock/product-stock.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  {path:"",redirectTo:"product",pathMatch:"full"},
  {path:"Product",component:ProductComponent},
  {path:"ProductStock",component:ProductStockComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
