import { Component, OnInit } from '@angular/core';
import { FormBuilder,  FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ShareDataService } from './ShareDataService';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
productGroup!:FormGroup
IsProductAdded:boolean = false;
productmessage:any="";
  constructor(private fb:FormBuilder,private shareDataService:ShareDataService,private router:Router){ } 


 ngOnInit(): void {
   this.productGroup=this.fb.group({
     productName:[''],
     price:[''],
     productDescription:['']
   })
  }


AddProduct(){
  this.shareDataService.changeMessage(this.productGroup.value.productName);
  this.router.navigate(["/ProductStock"]);
}
}
