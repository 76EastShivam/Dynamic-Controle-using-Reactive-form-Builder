
import { Component, OnInit } from '@angular/core';
import { ShareDataService } from '../product/ShareDataService';

@Component({
  selector: 'app-product-stock',
  templateUrl: './product-stock.component.html',
  styleUrls: ['./product-stock.component.css']
})
export class ProductStockComponent implements OnInit {

productName:any = "";
  constructor(private productname:ShareDataService) { }

  ngOnInit(): void {
    debugger;
    this.productname.currentMessage.subscribe(message =>(
      this.productName = message
    ))
  }

}
