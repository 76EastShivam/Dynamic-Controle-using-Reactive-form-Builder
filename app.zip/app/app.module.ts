import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { ProductStockComponent } from './product-stock/product-stock.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ShareDataService } from './product/ShareDataService';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    ProductStockComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [ShareDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
